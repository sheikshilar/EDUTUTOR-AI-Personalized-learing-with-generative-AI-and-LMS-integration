import React from 'react';
import { Brain, BookOpen, Settings, Zap, Users, Target, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';

function App() {
  const milestones = [
    {
      id: 1,
      title: "Requirements Specification",
      description: "Define system requirements and functional specifications for the AI-powered learning platform.",
      icon: Target,
      status: "completed",
      details: [
        "User story mapping and personas",
        "Functional requirements analysis",
        "Technical specifications documentation",
        "Integration requirements with LMS"
      ]
    },
    {
      id: 2,
      title: "Initialization Of Environment Variables",
      description: "Set up and configure necessary environment variables for seamless system integration.",
      icon: Settings,
      status: "in-progress",
      details: [
        "Development environment setup",
        "API keys and authentication",
        "Database configuration",
        "CI/CD pipeline initialization"
      ]
    },
    {
      id: 3,
      title: "AI Integration With IBM Watsonx",
      description: "Integrate generative AI capabilities using IBM Watsonx for personalized learning experiences.",
      icon: Brain,
      status: "planned",
      details: [
        "Watson AI model configuration",
        "Natural language processing setup",
        "Personalization algorithm development",
        "Performance optimization and testing"
      ]
    }
  ];

  const features = [
    {
      icon: Brain,
      title: "AI-Powered Personalization",
      description: "Advanced machine learning algorithms adapt to individual learning patterns and preferences."
    },
    {
      icon: BookOpen,
      title: "LMS Integration",
      description: "Seamless integration with existing Learning Management Systems for unified experience."
    },
    {
      icon: Users,
      title: "Collaborative Learning",
      description: "Foster peer-to-peer learning through intelligent matching and group formation."
    },
    {
      icon: Sparkles,
      title: "Generative Content",
      description: "Dynamic content generation tailored to specific learning objectives and styles."
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'in-progress': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'planned': return 'text-purple-600 bg-purple-50 border-purple-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="w-5 h-5 text-emerald-600" />;
      case 'in-progress': return <Zap className="w-5 h-5 text-blue-600" />;
      case 'planned': return <Target className="w-5 h-5 text-purple-600" />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  EduTutor AI
                </h1>
                <p className="text-sm text-gray-600">Personalized Learning Platform</p>
              </div>
            </div>
            <button className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg transform hover:scale-105 transition-all duration-200">
              Get Started
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <span className="inline-flex items-center px-4 py-2 bg-white/60 backdrop-blur-sm border border-white/30 rounded-full text-sm font-medium text-gray-700 mb-4">
              <Sparkles className="w-4 h-4 mr-2 text-yellow-500" />
              Powered by IBM Watsonx AI
            </span>
          </div>
          <h1 className="text-5xl sm:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            EduTutor AI: Personalized Learning With
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent block">
              Generative AI & LMS Integration
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
            Revolutionary AI-powered educational platform that adapts to individual learning patterns, 
            integrates seamlessly with existing LMS, and creates personalized learning experiences.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:shadow-xl transform hover:scale-105 transition-all duration-200 flex items-center justify-center">
              Explore Architecture
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
            <button className="px-8 py-4 bg-white/80 backdrop-blur-sm border border-white/30 text-gray-700 rounded-xl hover:bg-white hover:shadow-lg transform hover:scale-105 transition-all duration-200">
              View Demo
            </button>
          </div>
        </div>
      </section>

      {/* Architecture Overview */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Modular AI-Powered Architecture
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Built with scalability and flexibility in mind, our architecture ensures robust performance 
              and seamless integration capabilities.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group p-6 bg-white/60 backdrop-blur-sm border border-white/30 rounded-2xl hover:bg-white hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              >
                <div className="mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <feature.icon className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Project Milestones */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Project Milestones</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our structured approach to building the next generation of personalized learning platforms.
            </p>
          </div>

          <div className="space-y-8">
            {milestones.map((milestone, index) => (
              <div
                key={milestone.id}
                className="group bg-white/80 backdrop-blur-sm border border-white/30 rounded-2xl p-8 hover:shadow-xl transform hover:scale-[1.02] transition-all duration-300"
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex-1">
                    <div className="flex items-start space-x-4 mb-6">
                      <div className="flex-shrink-0">
                        <div className="w-14 h-14 bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                          <milestone.icon className="w-7 h-7 text-blue-600" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <span className="text-sm font-medium text-gray-500">
                            Milestone {milestone.id}
                          </span>
                          <div className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(milestone.status)}`}>
                            {getStatusIcon(milestone.status)}
                            <span className="ml-1 capitalize">{milestone.status.replace('-', ' ')}</span>
                          </div>
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-3">
                          {milestone.title}
                        </h3>
                        <p className="text-gray-600 mb-4 leading-relaxed">
                          {milestone.description}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="lg:ml-8 lg:flex-shrink-0">
                    <div className="bg-gray-50 rounded-xl p-6 lg:w-80">
                      <h4 className="font-semibold text-gray-900 mb-4">Key Deliverables</h4>
                      <ul className="space-y-2">
                        {milestone.details.map((detail, detailIndex) => (
                          <li key={detailIndex} className="flex items-center text-sm text-gray-600">
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 mr-3 flex-shrink-0" />
                            {detail}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-12 text-white">
            <h2 className="text-4xl font-bold mb-6">
              Ready to Transform Education?
            </h2>
            <p className="text-xl opacity-90 mb-8 leading-relaxed">
              Join us in revolutionizing personalized learning with AI-powered education technology 
              that adapts to every learner's unique needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-8 py-4 bg-white text-blue-600 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200">
                Start Project
              </button>
              <button className="px-8 py-4 bg-white/20 backdrop-blur-sm border border-white/30 text-white rounded-xl hover:bg-white/30 transform hover:scale-105 transition-all duration-200">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-white/80 backdrop-blur-sm border-t border-white/20">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="p-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">EduTutor AI</h3>
                <p className="text-sm text-gray-600">Powered by IBM Watsonx</p>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              © 2025 EduTutor AI. Transforming education through AI.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;